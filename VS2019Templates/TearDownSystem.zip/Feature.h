/*
Author: Gudakov Ramil Sergeevich a.k.a. Gauss
������� ������ ���������
Contacts: [ramil2085@mail.ru, ramil2085@gmail.com]
See for more information LICENSE.md.
*/

#pragma once

#include <ECS/include/Feature.h>

namespace ns
{
    class DllExport T$safeitemname$ : public nsECSFramework::TFeature
    {
        //TXXSystem mSystem;
        //TYYFeature mFeature;

    public:
        void InitConveyor() override;
    };
}