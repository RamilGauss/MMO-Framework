/*
Author: Gudakov Ramil Sergeevich a.k.a. Gauss
������� ������ ���������
Contacts: [ramil2085@mail.ru, ramil2085@gmail.com]
See for more information LICENSE.md.
*/

#pragma once

#include <ECS/include/IComponent.h>

namespace ns
{
    struct DllExport T$safeitemname$ : nsECSFramework::IComponent
    {
        std::string value;

        bool IsLess(const IComponent* pOther) const
        {
            return value < ((T$safeitemname$*) pOther)->value;
        }

        bool IsEqual(const IComponent* pOther) const
        {
            return value == ((T$safeitemname$*) pOther)->value;
        }
    };
}